function [Q R K P E eigenvalue kk]=lqrQR(A,B)
[a1,a2]=size(A);
[b1,b2]=size(B);
eigenvalue=eye(a1);
for i=1:a1;
    realeigen=-1*rand;
    imageigen=randi(5,1)*rand*((min(min(A))+max(max(A))*(rand*max(max(A))*100)^0.125)*max(max(B)))^0.5;
    eigenvalue(i,i)=realeigen+1i*(-1)^i*imageigen;
end
eigenvalue=real(eigenvalue);
kk=[];
bb=[];
for j=1:b1
    if B(j)==0
        bb(j,1)=1;
    else 
        bb(j,1)=B(j);
    end
end
for j=1:b1
    M=A-eigenvalue;
    Ki=max(M(:,j)./bb);
    kk=real([kk,Ki]);
end
y=0;
r=zeros(b2);
q=zeros(a1);
while y~=1000
    y=y+1;
    t=2*y*randi(2);
r=r+eye(b2).*rand(b2).*randi(2,b2,b2);
W=[];
for k=1:a1
    for v=1:a1
    w=(-1)^(k+v);
    W(k,v)=w;
    end
end
r=(r+rand*(t-y+1)*r/t)/2;
R=r/5;    
q=(q+(t*eye(a1)+(q+(sum(sum(r))*(round(rand(a1)).*(randi(100,a1,1)*ones(1,a1))+(eye(a1).*(randi(100,a1,1)*ones(1,a1))))/2))/2)/50)/2;
for m=1:(a1)^2
    if abs(q(m))<0.0001
        q(m)=0;
    end
end        
q=(tril(q)+(tril(q))')/2;
for m=1:(a1)^2
    if abs(q(m))<0.0001
        q(m)=0;
    end
end  
q=rand*(t-y+1)*q/t;
for m=1:(a1)^2
    if abs(q(m))<0.0001
        q(m)=0;
    end
end  
Q=q;
[K,P,E]=lqr(A,B,Q,R);
q=(abs(A'*P+P*eigenvalue)+(abs(A'*P+P*eigenvalue))')/2;
q=q.*Q/max(max(q))/100;
for m=1:(a1)^2
    if abs(q(m))<0.0001
        q(m)=0;
    end
end  
end

    


    