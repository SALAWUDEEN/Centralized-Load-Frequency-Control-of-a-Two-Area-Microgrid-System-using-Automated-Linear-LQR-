function generatePlots(y,yq,T)

% Plot results

figure("Name","Name One");
subplot(211)
plot(T, 50+y(:,1),'LineWidth',2);
hold on
plot(T, 50+yq(:,1),'LineWidth',2);
xlabel('Time (sec)');
ylabel('F1 (Hz)');
legend('trialLQR', 'AutoLQR');
subplot(212)
plot(T, 50+y(:,3),'LineWidth',2);
hold on
plot(T, 50+yq(:,3),'LineWidth',2);
xlabel('Time (sec)');
ylabel('F2 (Hz)');
legend('trialLQR', 'AutoLQR');

figure("Name","Name Two");
% plot(tspan, y(:,1), 'b', tspan, d, 'r--');
subplot(211)
plot(T, y(:,2),'LineWidth',2);
hold on
plot(T,yq(:,2),'LineWidth',2);
xlabel('Time (sec)');
ylabel('ACE (pu)');
legend('trialLQR', 'AutoLQR');
subplot(212)
plot(T, y(:,5),'LineWidth',2);
hold on
plot(T,yq(:,5),'LineWidth',2);
xlabel('Time (sec)');
ylabel('ACE (pu)');
legend('trialLQR', 'AutoLQR');
% title('LQR-Based Control of System with Input Disturbance');

figure("Name","Name Three");
plot(T, y(:,4),'LineWidth',2);
hold on
plot(T,yq(:,4),'LineWidth',2);
xlabel('Time (sec)');
ylabel('u(t) (Pu)');
legend('trialLQR', 'AutoLQR');

figure("Name","Name Four");
% plot(tspan, y(:,1), 'b', tspan, d, 'r--');
plot(T, y(:,6),'LineWidth',2);
hold
plot(T, yq(:,6),'LineWidth',2);
xlabel('Time (sec)');
ylabel('P_{Tie} (pu MW)');
legend('trialLQR', 'AutoLQR');

return
% title('LQR-Based Control of System with Input Disturbance');

% figure("Name","Name Five");
% % plot(tspan, y(:,1), 'b', tspan, d, 'r--');
% plot(T, y(:,5));
% xlabel('Time (sec)');
% ylabel('Output');
% legend('trialLQR', 'AutoLQR');
% % title('LQR-Based Control of System with Input Disturbance');

% figure("Name","Name Six");
% % plot(tspan, y(:,1), 'b', tspan, d, 'r--');
% plot(T, y(:,6));
% xlabel('Time (sec)');
% ylabel('Output');
% legend('trialLQR', 'AutoLQR');
% % title('LQR-Based Control of System with Input Disturbance');
% 
% figure("Name","Name All");
% % plot(tspan, y(:,1), 'b', tspan, d, 'r--');
% plot(T, y);
% xlabel('Time (sec)');
% ylabel('Output');
% legend('Output', 'Disturbance');
% title('LQR-Based Control of System with Input Disturbance');
