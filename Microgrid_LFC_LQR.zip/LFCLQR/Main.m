clc
clear all
close all
% This Code is develooped by Dr. Salawudeen Ahmed Tijani. 
%Feel free to use, edit and distribute. You can appreciated him by citing the
%following paper. 
% https://ieeexplore.ieee.org/abstract/document/10380869/
% You can also reach out to him on: atsalawudeen@tisahengineering.com


% Define system matrices
[A,B,C,D,W,G]=Plantmodel;
% Define disturbance matrix
% G = [1; 0];

% Define cost matrices
[Qq,Rq]=lqrQR(A,B)
Q = eye(size(A));
R = 1;
% 



% B = [B,G];

% Solve Riccati equation
[Kq, Pq, Eq] = lqr(A, B, Qq, Rq);% using Methods Proposed in Papers
[K, P, E] = lqr(A, B, Q, R);%Using Trial and Error

% Define closed-loop system
Ac = ss(A-B*K,B,C,D);
Aqc = ss(A-B*Kq,B,C,D);
% sys_LQAF=ss(A-B*KAF,B,C,D);
Bc = [B,G];
Cc = C;
Dc = D;

% Define simulation parameters

% tspan = 0:0.01:50;
x0 = [0.3;0;0;0;0;0;0;0;0;0;0;0;0;0];
% d = 0.5*sin(2*tspan);

% Simulate closed-loop system
% sys_cl = ss(Ac, [Bc G], Cc, [Dc 0]);
sys_cl = ss(A-B*K,Bc,Cc,D);
sys_clq = ss(A-B*Kq,Bc,Cc,D);
% X=initial(sys_cl,x0,tspan);
% T = 0:0.004:20;  % 201 points
% u = max(0,min(T-1,1));

% [u1,T] = gensig("pulse",3,3,0.002);
[u1,T] = gensig("pulse",10,20);
% U=[u1 u2 u1 u2];

[k,kk]=size(u1);
[m,mm]=size(Bc);
% size(ones(k,mm))
U=ones(k,mm).*u1;
[y, t, x] = lsim(sys_cl, U', T, x0);
[yq, tq, xq] = lsim(sys_clq, U', T, x0);

%% Plot the responces
generatePlots(y,yq,T)
