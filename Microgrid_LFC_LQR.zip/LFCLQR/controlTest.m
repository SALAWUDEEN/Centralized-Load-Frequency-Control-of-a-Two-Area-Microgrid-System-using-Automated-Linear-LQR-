function [CONTR_RANK,OBSV_RANK]=controlTest(A,B,C)
%% Perform Controllability and observability test
Mcr=ctrb(A,B);
Mob=obsv(A,C);
if rank(Mcr)==size(A)
    'System is Controlable'
else
    'System is NOT Controlable'
end
CONTR_RANK=rank(Mcr);
if rank(Mob)==size(A)
    'System is Observable'
else
    'System is NOT Observable'
end
OBSV_RANK=rank(Mob);